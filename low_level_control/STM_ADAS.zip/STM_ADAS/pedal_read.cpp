#include <Arduino.h>

const int analog_pin = A1; 

void setup(){
    Serial.begin(9600);
    while (!Serial) {
        delay(10);
    }
    
    pinMode(analog_pin, INPUT);
}

void loop(){

    // Read the analog value
    int rawValue = analogRead(analog_pin);
    
    // Print the raw value
    Serial.print("Raw ADC Value: ");
    Serial.println(rawValue);
    
    // Add a small delay to avoid flooding the serial output
    delay(100);  // Adjust as needed

}